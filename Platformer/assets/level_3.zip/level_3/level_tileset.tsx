<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="level_tileset" tilewidth="16" tileheight="16" tilecount="324" columns="18">
 <image source="../../SOFTWARE ENGINEERING/Rocky Roads/Tilesets/Foozle_2DT0001_Science_Fiction_Labs_Tileset/Tileset/level_tileset.png" width="300" height="300"/>
</tileset>
