<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="mountains" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="98" columns="14">
 <image source="Rocky Roads/Backgrounds/mountains_a.png" width="256" height="128"/>
</tileset>
