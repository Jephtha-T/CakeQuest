<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Forest" tilewidth="16" tileheight="16" tilecount="72" columns="12">
 <image source="Rocky Roads/Tilesets/tileset_forest.png" width="192" height="96"/>
</tileset>
