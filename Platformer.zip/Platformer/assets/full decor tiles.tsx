<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="full decor tiles" tilewidth="16" tileheight="16" tilecount="36" columns="6">
 <image source="../../SOFTWARE ENGINEERING/Rocky Roads/Tilesets/Foozle_2DT0001_Science_Fiction_Labs_Tileset/Decor/full decor tiles.png" width="96" height="96"/>
</tileset>
