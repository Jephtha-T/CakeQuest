<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="estrelas" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="378" columns="42">
 <image source="estrelas.png" width="768" height="170"/>
</tileset>
