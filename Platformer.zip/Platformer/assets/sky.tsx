<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="sky" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="252" columns="21">
 <image source="../../Downloads/Glacial-mountains-parallax-background_vnitti_v3/Glacial-mountains-parallax-background_vnitti/Layers/sky_lightened.png" width="384" height="216"/>
</tileset>
