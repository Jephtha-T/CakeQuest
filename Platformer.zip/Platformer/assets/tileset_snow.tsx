<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tileset_snow" tilewidth="16" tileheight="16" tilecount="66" columns="11">
 <image source="Rocky Roads/Tilesets/tileset_snow.png" width="176" height="96"/>
</tileset>
