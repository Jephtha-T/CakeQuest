package com.mygdx.game.Sprites;

public class SpikeObstacle {
}
