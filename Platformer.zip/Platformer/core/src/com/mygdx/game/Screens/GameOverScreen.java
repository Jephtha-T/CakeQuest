package com.mygdx.game.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.Game;
import com.mygdx.game.MyGdxGame;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.viewport.FillViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.OrthographicCamera;

public class GameOverScreen implements Screen {
    private Game game;
    private SpriteBatch batch;
    private Sprite splash;
    private Sprite playButton;
    private Sprite LevelButton;
    private Sprite MainButton;
    private Texture buttonTexture;
    private Texture buttonHoverTexture;
    private Texture LevelbuttonTexture;
    private Texture LevelbuttonHoverTexture;
    private Texture MainbuttonTexture;
    private Texture MainbuttonHoverTexture;
    private boolean PlayisHovering;
    private boolean LevelisHovering;
    private boolean MainisHovering;
    private Viewport viewport;
    private Camera camera;
    private Music music;
    public String levelname;

    public GameOverScreen(Game game, String level) {
        this.game = game;
        levelname = level;
    }

    @Override
    public void show() {
        batch = new SpriteBatch();

        // Create camera and viewport
        camera = new OrthographicCamera();
        viewport = new FillViewport(MyGdxGame.V_WIDTH, MyGdxGame.V_HEIGHT, camera); // Use predefined dimensions
        viewport.apply();
        music = MyGdxGame.manager.get("Audio/bgmenu.mp3", Music.class);
        music.setLooping(true);
        music.play();

        // Load textures
        Texture splashTexture = new Texture("Menu/GameOverbg.jpg");
        buttonTexture = new Texture("Menu/replaybtn.png");
        buttonHoverTexture = new Texture("Menu/replaybtn_hover.png");
        LevelbuttonTexture = new Texture("Menu/replaybtn.png");
        LevelbuttonHoverTexture = new Texture("Menu/replaybtn_hover.png");
        MainbuttonTexture = new Texture("Menu/replaybtn.png");
        MainbuttonHoverTexture = new Texture("Menu/replaybtn_hover.png");

        // Create sprites
        splash = new Sprite(splashTexture);
        splash.setSize(MyGdxGame.V_WIDTH, MyGdxGame.V_HEIGHT); // Use predefined dimensions

        playButton = new Sprite(buttonTexture);
        LevelButton = new Sprite(LevelbuttonTexture);
        MainButton = new Sprite(MainbuttonTexture);

        // Set the size of the button
        float buttonWidth = 150; // Adjust the width as needed
        float buttonHeight = 150; // Increase the height as needed
        playButton.setSize(buttonWidth, buttonHeight);
        LevelButton.setSize(buttonWidth, buttonHeight);
        MainButton.setSize(buttonWidth, buttonHeight);


        // Position the button in the middle of the screen
        playButton.setPosition(
                (MyGdxGame.V_WIDTH - playButton.getWidth()) / 2,
                MyGdxGame.V_HEIGHT / 5 - playButton.getHeight() / 2 // Center vertically
        );
        LevelButton.setPosition(
                (MyGdxGame.V_WIDTH - playButton.getWidth()) / 2,
                (MyGdxGame.V_HEIGHT / 5 - playButton.getHeight() / 2) - 150 // Center vertically
        );
        MainButton.setPosition(
                (MyGdxGame.V_WIDTH - playButton.getWidth()) / 2,
                (MyGdxGame.V_HEIGHT / 5 - playButton.getHeight() / 2) - 300 // Center vertically
        );
    }


    @Override
    public void dispose() {
        batch.dispose();
        splash.getTexture().dispose();
        playButton.getTexture().dispose();
        buttonHoverTexture.dispose();
        LevelButton.getTexture().dispose();
        LevelbuttonHoverTexture.dispose();
        MainButton.getTexture().dispose();
        MainbuttonHoverTexture.dispose();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
        batch.setProjectionMatrix(camera.combined);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.begin();
        splash.draw(batch);

        // Convert mouse coordinates to world coordinates
        Vector3 mousePos = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);
        camera.unproject(mousePos);

        // Check if the mouse is hovering over the button
        if ((mousePos.x >= playButton.getX() &&
                mousePos.x <= playButton.getX() + playButton.getWidth()) &&
                (mousePos.y >= playButton.getY()+50 &&
                        mousePos.y <= playButton.getY() + playButton.getHeight()-50)) {
            PlayisHovering = true;
            playButton.setTexture(buttonHoverTexture);
        } else {
            PlayisHovering = false;
            playButton.setTexture(buttonTexture);
        }

        playButton.draw(batch);

        if ((mousePos.x >= LevelButton.getX() &&
                mousePos.x <= LevelButton.getX() + LevelButton.getWidth()) &&
                (mousePos.y >= LevelButton.getY()+50 &&
                        mousePos.y <= LevelButton.getY() + LevelButton.getHeight()-50)) {
            LevelisHovering = true;
            LevelButton.setTexture(LevelbuttonHoverTexture);
        } else {
            LevelisHovering = false;
            LevelButton.setTexture(LevelbuttonTexture);
        }

        LevelButton.draw(batch);

        if ((mousePos.x >= MainButton.getX() &&
                mousePos.x <= MainButton.getX() + MainButton.getWidth()) &&
                (mousePos.y >= MainButton.getY()+50 &&
                        mousePos.y <= MainButton.getY() + MainButton.getHeight()-50)) {
            MainisHovering = true;
            MainButton.setTexture(MainbuttonHoverTexture);
        } else {
            MainisHovering = false;
            MainButton.setTexture(MainbuttonTexture);
        }

        MainButton.draw(batch);
        batch.end();

        // Handle input
        if (Gdx.input.justTouched() && PlayisHovering) {
            // Button is pressed, transition to PlayScreen
            game.setScreen(new PlayScreen((MyGdxGame) game, levelname)); // Cast the game instance to MyGdxGame
            music.setLooping(false);
            music.stop();
        }
        else if (Gdx.input.justTouched() && LevelisHovering) {
            // Button is pressed, transition to PlayScreen
            goToLevelSelect();
        }
        else if (Gdx.input.justTouched() && MainisHovering) {
            // Button is pressed, transition to PlayScreen
            goToMainMenu();
        }
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide(){
    }
    private void goToMainMenu() {
        game.setScreen(new MenuScreen(game));
        music.setLooping(false);
        music.stop();
    }

    private void goToLevelSelect() {
        game.setScreen(new LevelScreen(game));
        music.setLooping(false);
        music.stop();
    }
}